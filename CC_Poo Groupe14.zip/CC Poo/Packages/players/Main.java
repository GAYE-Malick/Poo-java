package players;
import java.util.Scanner;
import java.util.Random;
import players.*;
import plays.*;
import games.*;

public class Main
{
  public static void main(String[] args)
  {
    Scanner scanner=new Scanner(System.in);
    Random rand = new Random(123);
    Player player1 = new RandomPlayer(rand);
    Player player2 = new Human("Moi", scanner);
    TicTacToe game = new TicTacToe(player1, player2);
    Orchestrator orchestrator = new Orchestrator(game);
    orchestrator.play();
    scanner.close();
  }
}
