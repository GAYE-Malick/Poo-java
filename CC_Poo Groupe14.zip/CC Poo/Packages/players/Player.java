package players;
import games.Game;
public interface Player
{
  public int chooseMove(Game jeu);
}
